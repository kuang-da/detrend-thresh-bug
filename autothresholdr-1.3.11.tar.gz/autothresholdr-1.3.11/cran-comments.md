## Test environments
* local OS X install, R 4.0.3
* ubuntu 16.04 (on travis-ci), R 4.0.3
* Windows Server 2012 (on appveyor), R 4.0.3
* win-builder (devel and release)

## R CMD check results
* 0 ERRORs | 0 WARNINGs | 0 NOTEs

## Reverse Dependencies
* There are 2 reverse dependencies: `detrendr` and `nandb`. This update does not break either.
