library(testthat)
library(autothresholdr)

test_check("autothresholdr")
