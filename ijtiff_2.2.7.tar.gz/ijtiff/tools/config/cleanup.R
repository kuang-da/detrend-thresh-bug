# Clean up files generated during configuration here.
# Use 'remove_file()' to remove files generated during configuration.

remove_file("src/Makevars")
